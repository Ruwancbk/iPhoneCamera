# iPhone Camera Android App

An Android camera app that mimics iPhone-style photo processing.

## Build
Push to main → GitHub Actions → Download APK from Artifacts.

## Features
- CameraX camera preview
- iPhone-style color grading (warm tone, higher contrast, saturated)
- Saves to Gallery (Pictures/iPhoneCam)
