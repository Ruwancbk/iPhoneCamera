package com.ruwancbk.iphoncamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import jp.co.cyberagent.android.gpuimage.GPUImage
import jp.co.cyberagent.android.gpuimage.filter.GPUImageColorMatrixFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageContrastFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilterGroup
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSaturationFilter
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var btnCapture: ImageButton
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private lateinit var gpuImage: GPUImage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewFinder = findViewById(R.id.viewFinder)
        btnCapture = findViewById(R.id.btnCapture)
        cameraExecutor = Executors.newSingleThreadExecutor()
        gpuImage = GPUImage(this)

        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this, requiredPermissions(), REQUEST_CODE)

        btnCapture.setOnClickListener { takePhoto() }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Camera failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val cap = imageCapture ?: return
        // Heavy work runs on the background executor, not the UI thread
        cap.takePicture(cameraExecutor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val rotation = image.imageInfo.rotationDegrees
                    val bmp = imageProxyToBitmap(image, rotation)
                    image.close()
                    if (bmp != null) applyIPhoneLook(bmp)
                }
                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            })
    }

    private fun imageProxyToBitmap(image: ImageProxy, rotationDegrees: Int): Bitmap? {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        if (rotationDegrees == 0) return bmp
        val m = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun applyIPhoneLook(original: Bitmap) {
        try {
            val group = GPUImageFilterGroup()
            group.addFilter(GPUImageContrastFilter(1.08f))
            group.addFilter(GPUImageSaturationFilter(1.10f))
            val warm = GPUImageColorMatrixFilter().apply {
                setColorMatrix(floatArrayOf(
                    1.06f, 0.02f, 0f, 0f,
                    0f, 1.03f, 0f, 0f,
                    0f, 0.01f, 0.96f, 0f,
                    0f, 0f, 0f, 1f
                ))
                setIntensity(1.0f)
            }
            group.addFilter(warm)

            gpuImage.setImage(original)
            gpuImage.setFilter(group)
            val filtered = gpuImage.bitmapWithFilterApplied

            val ok = saveBitmap(filtered)
            runOnUiThread {
                Toast.makeText(this, if (ok) "iPhone Look Saved to Gallery!" else "Save failed", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Throwable) {
            runOnUiThread {
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Saves into Pictures/iPhoneCam so it shows up in the Gallery
    private fun saveBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "iPhone_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/iPhoneCam")
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        contentResolver.openOutputStream(uri)?.use {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it)
        } ?: return false
        return true
    }

    private fun requiredPermissions(): Array<String> {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return list.toTypedArray()
    }

    private fun allPermissionsGranted() = requiredPermissions().all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<String>, g: IntArray) {
        super.onRequestPermissionsResult(rc, p, g)
        if (rc == REQUEST_CODE && allPermissionsGranted()) startCamera()
        else { Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show(); finish() }
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }

    companion object {
        private const val REQUEST_CODE = 10
    }
}
